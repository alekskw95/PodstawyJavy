package java3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class OdczytPliku {
    //psvm i tabulator
    public static void main(String[] args) {
        
        String napis = "ala ma kota"; //podzielic napis na wyrazy
        
        String[] tabNapisow = napis.split(" ");
        
        for(String o : tabNapisow)  //po czym interowal po tablicy napisow
            System.out.println(o);
        
        System.out.println("-----Z pliku------");
        try {
            Scanner sc = new Scanner(new File("plik.txt"));
            
            while(sc.hasNextLine())
                System.out.println(sc.nextLine());
            
            
            sc.close();
        } catch (FileNotFoundException ex) {
            System.out.println("Problem z odczytem pliku.");
        }
    }
    
}

package java3;

public class ZadanieDomowe {
    
    public static void main(String[] args) {
        
        //Napisz program ktory odczyta plik liczby.txt
        //a nastepnie wypisze na ekran obie liczby oraz sume roznice iloczyn iloraz srednie z dwoch liczb
        //branych kazda z nowej lini
    }
    
}

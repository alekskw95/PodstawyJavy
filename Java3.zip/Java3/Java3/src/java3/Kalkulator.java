package java3;

import java.text.DecimalFormat;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Kalkulator {

   
    //100*45,562556677... -> round 
    public static double zaokr(double l)
    {
        return Math.floor(l*100)/100.0;
    }
 
    public static void main(String[] args) {
        try{
        DecimalFormat d = new DecimalFormat();
        d.setMaximumFractionDigits(2);
        
        System.out.println("Hello");

        Scanner sc = new Scanner(System.in); //wybieramy pierwsze z zarkowki
        
       // System.out.print("Przedstaw sie: ");
        //String odczyt = sc.next();    // tekst ze spacja to obcina i wyswietla pierwsze 
        //String odczyt = sc.nextLine(); //czyta caly tekst dzielony spacja
        //System.out.println(odczyt); 
        
        //iloraz liczb ? / 0
        //srednia arytmetyczna liczb(a+b)/2
        //srednia geomatryczna liczb >0 >=0 sqrt(a*b)
        
        System.out.println("-------Kalkulator---------");
        
        System.out.print("Podaj pierwsza liczbe: ");
        int liczba1 = sc.nextInt();
        
        System.out.print("Podaj druga liczbe: ");
        int liczba2 = sc.nextInt();
        
        System.out.println("Suma liczb: "+liczba1+" i "+liczba2+" wynosi "+(liczba1+liczba2));
        System.out.println("Roznica liczb: "+liczba1+" i "+liczba2+" wynosi "+(liczba1-liczba2));
        System.out.println("Iloczyn liczb: "+liczba1+" i "+liczba2+" wynosi "+(liczba1*liczba2));
        if(liczba2!=0)
        {
           // System.out.println("Iloraz liczb: "+liczba1+" i "+liczba2+" wynosi "+(d.format((double)liczba1/liczba2))); //konwersja na double
            System.out.println("Iloraz liczb: "+liczba1+" i "+liczba2+" wynosi "+zaokr((double)liczba1/liczba2));
        }
        else
            System.out.println("Dzielenie nei wykonalne"); 
       
        System.out.println("Srednia arytmetyczna: "+liczba1+" i "+liczba2+" wynosi "+((liczba1+liczba2)/2.0));
        if((liczba1 >= 0) && (liczba2 >=0))
        {
            System.out.println("Srednia geometryczna: "+liczba1+" i "+liczba2+" wynosi "+zaokr(Math.sqrt(liczba1*liczba2)));
        }
        else
            System.out.println("Srednia geomatryczna nie istenije");
        
        
        sc.close();
        
}
    catch(InputMismatchException e)
    {
        System.out.println("Blednie podana liczba");
    }
    }
}
    
